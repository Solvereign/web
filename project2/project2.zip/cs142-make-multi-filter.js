'use strict';
function cs142MakeMultiFilter(originalArray) {

	function filt(filterCriteria, callback) {

		if(filt.currentArray === undefined) {
			filt.currentArray = originalArray;
		}
		if(filterCriteria === undefined) {
			return filt.currentArray;
		}
		filt.currentArray = filt.currentArray.filter((val) => filterCriteria(val));
		
		if(typeof callback === "function") {
			callback.call(originalArray, filt.currentArray);
		}
		return filt;

	}
	return filt;
}